<?
	$valor = $_GET["cNome"];
	echo "O nome enviado e $valor";
?>