<?php

/**
 * Defines common elements used by the library.
 */
if (!function_exists('__')) {
    /**
     * Translates the given string.
     *
     * @param string $str string to be translated
     *
     * @return string
     */
    function __($str)
    {
        return $str;
    }
}
